

<?php $__env->startSection('content'); ?>
    <!-- Hero Section -->
    <section class="hero-section position-relative overflow-hidden">
        <div class="container py-5">
            <div class="row align-items-center">
                <!-- Teks Kiri -->
                <div class="col-md-6">
                    <h1 class="display-4 fw-bold mb-3">
                        Makanan & Minuman <br> Terbaik untuk Anda
                    </h1>
                    <p class="lead mb-4">
                        Nikmati berbagai pilihan makanan dan minuman berkualitas dengan rasa istimewa.
                        Siap dipesan kapan saja!
                    </p>
                    <a href="#" class="btn btn-primary btn-lg">Jelajahi Menu</a>
                </div>

                <!-- Gambar Kanan -->
                <div class="col-md-6 text-center mt-4 mt-md-0">
                    <!-- Ganti src dengan path gambarmu -->
                    <img src="<?php echo e(asset('images/contoh-makanan.png')); ?>" alt="Makanan & Minuman" class="img-fluid" style="max-height: 400px;">
                </div>
            </div>
        </div>

        <!-- Wave di bagian bawah Hero -->
        <div class="wave-container">
            <svg viewBox="0 0 1440 320" xmlns="http://www.w3.org/2000/svg">
                <path fill="#fff" fill-opacity="1"
                      d="M0,224L48,224C96,224,192,224,288,224C384,224,480,224,576,192C672,160,768,96,864,69.3C960,43,1056,53,1152,80C1248,107,1344,149,1392,170.7L1440,192L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z">
                </path>
            </svg>
        </div>
    </section>

    <!-- Bagian Lain (misalnya daftar produk) -->
    <section class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">Kategori Produk</h2>
            <!-- Contoh Kategori -->
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card border-0 shadow">
                        <img src="<?php echo e(asset('images/makanan1.jpg')); ?>" class="card-img-top" alt="Makanan 1">
                        <div class="card-body">
                            <h5 class="card-title">Makanan</h5>
                            <p class="card-text">Aneka makanan lezat dan terjangkau.</p>
                            <a href="#" class="btn btn-outline-primary">Lihat Detail</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow">
                        <img src="<?php echo e(asset('images/minuman1.jpg')); ?>" class="card-img-top" alt="Minuman 1">
                        <div class="card-body">
                            <h5 class="card-title">Minuman</h5>
                            <p class="card-text">Segarkan harimu dengan minuman pilihan.</p>
                            <a href="#" class="btn btn-outline-primary">Lihat Detail</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow">
                        <img src="<?php echo e(asset('images/snack1.jpg')); ?>" class="card-img-top" alt="Snack 1">
                        <div class="card-body">
                            <h5 class="card-title">Snack</h5>
                            <p class="card-text">Camilan ringan untuk menemani aktivitas.</p>
                            <a href="#" class="btn btn-outline-primary">Lihat Detail</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sabiru-market\resources\views/homepage.blade.php ENDPATH**/ ?>